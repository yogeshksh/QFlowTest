﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using QFlow_EventBooking_ViewModels;

namespace QFlow_EventBooking.Apis
{
    [Route("api/authenticate")]
    public class AuthenticateController : Controller
    {

        // POST: api/Authenticate
        [HttpPost]
        public IActionResult Post([FromBody] LoginRequestViewModel value)
        {

            try
            {
                if (ModelState.IsValid)
                {
                    //TODO - just return hard coded value
                    value.Password = null;
                    value.Usertype = 1;
                    return Ok(value);
                }
                value.Password = null;
                value.Usertype = 0;
                return Ok(value);
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}





