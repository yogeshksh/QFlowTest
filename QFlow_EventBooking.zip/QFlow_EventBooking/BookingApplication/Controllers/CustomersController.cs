using QFlow_EventBooking.Infrastructure;
using QFlow_EventBooking.Models;
using QFlow_EventBooking.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace QFlow_EventBooking.Controllers
{
    /// <summary>
    /// APis for customers and customer
    /// </summary>
    [Route("api/customers")]
    public class CustomersController : Controller
    {
        ICustomersRepository _customersRepository;
        ILogger _logger;

        public CustomersController(ICustomersRepository customersRepo, ILoggerFactory loggerFactory) {
            _customersRepository = customersRepo;
            _logger = loggerFactory.CreateLogger(nameof(CustomersController));
        }
        /// <summary>
        /// return all customer
        /// </summary>
        /// <returns></returns>
        // GET api/customers
        [HttpGet]
        [NoCache]
        [ProducesResponseType(typeof(List<Customer>), 200)]
        [ProducesResponseType(typeof(ApiResponse<Customer>), 400)]
        public async Task<ActionResult> Get()
        {
            try
            {
                var customers = await _customersRepository.GetCustomersAsync();
                return Ok(customers);
            }
            catch (Exception exp)
            {
                _logger.LogError(exp.Message);
                return BadRequest(new ApiResponse<Customer> { Status = false });
            }
        }


        // GET api/customers/5
        [HttpGet("{id}", Name = "GetCustomerRoute")]
        [NoCache]
        [ProducesResponseType(typeof(Customer), 200)]
        [ProducesResponseType(typeof(ApiResponse<Customer>), 400)]
        public async Task<ActionResult> Get(int id)
        {
            try
            {
                var customer = await _customersRepository.GetCustomerAsync(id);
                return Ok(customer);
            }
            catch (Exception exp)
            {
                _logger.LogError(exp.Message);
                return BadRequest(new ApiResponse<Customer> { Status = false });
            }
        }

       
    }
}
