﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using QFlow_EventBooking.Infrastructure;
using QFlow_EventBooking.Models;
using QFlow_EventBooking.Repository;

namespace QFlow_EventBooking.Apis
{
    [Route("api/eventorder")]
    public class EventOrderController : Controller
    {
        private readonly IEventOrderRepository _eventOrderRepository;
        private readonly ILogger _logger;

        public EventOrderController(IEventOrderRepository eventorderRepo, ILoggerFactory loggerFactory)
        {
            _eventOrderRepository = eventorderRepo;
            _logger = loggerFactory.CreateLogger(nameof(EventOrderController));
        }
        // POST api/EventOrder
        [HttpPost()]
        [ValidateAntiForgeryToken]
        [ProducesResponseType(typeof(ApiResponse<Order>), 201)]
        [ProducesResponseType(typeof(ApiResponse<Order>), 400)]
        public IActionResult CreateCustomerEventOrder([FromBody]CustomerEventOrder customerOrderdetails)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new ApiResponse<Order> { Status = false, ModelState = ModelState });
            }
            try
            {
                var newOrder =  _eventOrderRepository.CreateEventOrder(customerOrderdetails.Customer.Id, customerOrderdetails.Event, customerOrderdetails.NumberOfTickets);
                if (newOrder == null)
                {
                    return BadRequest(new ApiResponse<Order> { Status = false });
                }
                return CreatedAtRoute("GetCustomerEvent", new { id = newOrder.Id },
                        new ApiResponse<Order> { Status = true, ResponseObject = newOrder });
            }
            catch (Exception exp)
            {
                _logger.LogError(exp.Message);
                return BadRequest(new ApiResponse<Order> { Status = false });
            }
        }

        // PUT api/eventorder/5
        [HttpPut("{custId}")]
        [ValidateAntiForgeryToken]
        [ProducesResponseType(typeof(ApiResponse<Order>), 200)]
        [ProducesResponseType(typeof(ApiResponse<Order>), 400)]
        public  IActionResult UpdateCustomerEventOrder(int custId, [FromBody]Order order)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new ApiResponse<Order> { Status = false, ModelState = ModelState });
            }
            try
            {
                var status = _eventOrderRepository.UpdateEventOrder(custId, order);
                return Ok(status);
            }
            catch (Exception exp)
            {
                _logger.LogError(exp.Message);
                return BadRequest(new ApiResponse<Order> { Status = false });
            }
        }

        // DELETE api/customers/5
        [HttpDelete("{custId, orderId}")]
        [ValidateAntiForgeryToken]
        [ProducesResponseType(typeof(ApiResponse<Order>), 200)]
        [ProducesResponseType(typeof(ApiResponse<Order>), 400)]
        public  IActionResult DeleteCustomerEventOrder(int custId, int orderId)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new ApiResponse<Order> { Status = false, ModelState = ModelState });
            }
            try
            {
                var status = _eventOrderRepository.CancelEventOrder(custId, orderId);
                return Ok(status);
            }
            catch (Exception exp)
            {
                _logger.LogError(exp.Message);
                return BadRequest(new ApiResponse<Order> { Status = false });
            }
        }
    }
}