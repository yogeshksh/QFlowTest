
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using QFlow_EventBooking.Infrastructure;
using QFlow_EventBooking.Models;
using QFlow_EventBooking.Repository;

namespace QFlow_EventBooking.Apis
{
    [Route("api/events")]
    public class EventsController : Controller
    {
        private readonly IEventsRepository _eventsRepository;
        private readonly ILogger _logger;

        public EventsController(IEventsRepository eventsRepo, ILoggerFactory loggerFactory)
        {
            _eventsRepository = eventsRepo;
            _logger = loggerFactory.CreateLogger(nameof(EventsController));
        }
        /// <summary>
        /// API method to return all event details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [NoCache]
        [ProducesResponseType(typeof(List<Event>), 200)]
        [ProducesResponseType(typeof(ApiResponse<Event>), 400)]
        public async Task<ActionResult> Get() {
            try
            {
                var events = await _eventsRepository.GetEventsAsync();
                return Ok(events);
            }
            catch (Exception exp)
            {
                _logger.LogError(exp.Message);
                return BadRequest(new ApiResponse<Event> { Status = false });
            }
        }
        /// <summary>
        /// API method to return event details for the specific event based on event id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        [NoCache]
        [ProducesResponseType(typeof(List<Event>), 200)]
        [ProducesResponseType(typeof(ApiResponse<Event>), 400)]
        public async Task<ActionResult> Get(int id)
        {
            try
            {
                var eventdetail = await _eventsRepository.GetEventAsync(id);
                return Ok(eventdetail);
            }
            catch (Exception exp)
            {
                _logger.LogError(exp.Message);
                return BadRequest(new ApiResponse<Event> { Status = false });
            }
        }

    }
}
