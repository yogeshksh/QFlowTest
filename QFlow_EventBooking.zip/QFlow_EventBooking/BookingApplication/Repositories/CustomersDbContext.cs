using Microsoft.EntityFrameworkCore;
using QFlow_EventBooking.Models;

namespace QFlow_EventBooking.Repository
{
    public class CustomersDbContext : DbContext
    {
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Event> Events { get; set; }
        public CustomersDbContext (DbContextOptions<CustomersDbContext> options) : base(options) { }
    }
}