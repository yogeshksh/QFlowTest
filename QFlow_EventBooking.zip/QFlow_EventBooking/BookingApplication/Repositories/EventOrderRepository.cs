﻿using QFlow_EventBooking.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace QFlow_EventBooking.Repository
{
    public class EventOrderRepository : IEventOrderRepository
    {
        private readonly CustomersDbContext _context;
        private readonly ILogger _logger;

        public EventOrderRepository(CustomersDbContext context, ILoggerFactory loggerFactory)
        {
            _context = context;
            _logger = loggerFactory.CreateLogger(nameof(EventOrderRepository));
        }
        /// <summary>
        /// cancel booked event for specific customer
        /// </summary>
        /// <param name="customerId"></param>
        /// <param name="eventId"></param>
        /// <returns></returns>
        public bool CancelEventOrder(int customerId, int orderId)
        {
            return false;
        }

        /// <summary>
        /// create a order for a customer to book specified event with number of tickets
        /// </summary>
        /// <param name="customerId"></param>
        /// <param name="eventdetail"></param>
        /// <param name="numberoftickets"></param>
        /// <returns></returns>
        public Order CreateEventOrder(int customerId, Event eventdetail, int numberoftickets)
        {
            return null;
        }

        public bool UpdateEventOrder(int customerId, Order order)
        {
            return false;
        }
    }
}
