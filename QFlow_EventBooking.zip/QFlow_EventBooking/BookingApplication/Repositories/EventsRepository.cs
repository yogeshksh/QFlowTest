﻿using QFlow_EventBooking.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QFlow_EventBooking.Repository
{
    public class EventsRepository : IEventsRepository
    {
        private readonly CustomersDbContext _context;
        private readonly ILogger _logger;

        public EventsRepository(CustomersDbContext context, ILoggerFactory loggerFactory)
        {
            _context = context;
            _logger = loggerFactory.CreateLogger(nameof(EventsRepository));
        }
        /// <summary>
        /// return all events from the database using entity framework, Ideally use generic unity of work and repository pattern to return the data after executing 
        /// stored procedure
        /// </summary>
        /// <returns></returns>
        public async Task<List<Event>> GetEventsAsync()
        {
            return await _context.Events.OrderBy(e => e.Name).ToListAsync();
        }
        /// <summary>
        /// return events from database based on event id using entity framework 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<Event> GetEventAsync(int id)
        {
            return await Task.FromResult(_context.Events.FirstOrDefault(e=>e.Id ==id));
        }
    }
}
