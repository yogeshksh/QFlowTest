﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace QFlow_EventBooking.Repository
{

    /// <summary>
    /// this class to provide generica database repository operation based on unit of work and repository pattern which can be invoked
    /// from concrete repository for database oeprations
    /// </summary>
    public class GenericDatabaseRepository : IGenericDatabaseRepository
    {
        private DbContext _context;
        public GenericDatabaseRepository (DbContext dbcontext)
        {
            _context = dbcontext;
        }
        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public void ExecuteNonQuery(string commandText, CommandType commandType, SqlParameter[] sqlParameters = null)
        {
            throw new NotImplementedException();
        }

        public ICollection ExecuteSQLQuery(string sql, CommandType commandType, SqlParameter[] sqlParameters = null)
        {
            throw new NotImplementedException();
        }
    }
}
