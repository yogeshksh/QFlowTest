﻿using System.Collections.Generic;
using System.Threading.Tasks;
using QFlow_EventBooking.Models;

namespace QFlow_EventBooking.Repository
{
    public interface IEventOrderRepository
    {
        bool CancelEventOrder(int customerId, int orderId);
        bool UpdateEventOrder(int customerId, Order order);
        Order CreateEventOrder(int customerId, Event eventdetail, int numberoftickets);
    }
}