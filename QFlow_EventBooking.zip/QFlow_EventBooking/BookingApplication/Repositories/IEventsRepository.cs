﻿using System.Collections.Generic;
using System.Threading.Tasks;
using QFlow_EventBooking.Models;

namespace QFlow_EventBooking.Repository
{
    public interface IEventsRepository
    {
        Task<List<Event>> GetEventsAsync();
        Task<Event> GetEventAsync(int id);
    }
}