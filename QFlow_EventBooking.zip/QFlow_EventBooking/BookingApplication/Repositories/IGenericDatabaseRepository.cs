﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace QFlow_EventBooking.Repository
{
    public interface IGenericDatabaseRepository : IDisposable
    {
        ICollection ExecuteSQLQuery(string sql, System.Data.CommandType commandType, SqlParameter[] sqlParameters =null);

        void ExecuteNonQuery(string commandText, System.Data.CommandType commandType, SqlParameter[] sqlParameters = null);
    }
}
