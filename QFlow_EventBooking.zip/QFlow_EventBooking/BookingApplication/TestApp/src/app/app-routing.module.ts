import { NgModule } from '@angular/core';  
import { Routes, RouterModule } from '@angular/router';  
import { DashboardComponent } from './dashboard/dashboard.component';
import { OrderEditComponent } from './orders/order-edit.component';
import { OrderListComponent } from './orders/order-list.component';
import { CustomerComponent } from './customers/customer.component';
import { EventListComponent } from './events/event-list.component';
import { LoginComponent } from './login/login.component';
import { UserLogoutComponent } from './login/user-logout.component';

const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
  { path: 'orders/:id', component: OrderEditComponent },
  { path: '**', pathMatch: 'full', redirectTo: '/dashboard' }, //catch any unfound routes and redirect to dashboard page - time being for this exercise
  { path: 'Login', component: LoginComponent },
  { path: 'UserLogout', component: UserLogoutComponent },
  { path: '', redirectTo: "Login", pathMatch: 'full' },
  { path: '**', redirectTo: "Login", pathMatch: 'full' },
];

@NgModule({  
  imports: [RouterModule.forRoot(routes)],  
  exports: [RouterModule]  
})  
export class AppRoutingModule
{
  static components = [DashboardComponent, OrderEditComponent, OrderListComponent, EventListComponent, CustomerComponent, LoginComponent, UserLogoutComponent];
}  





