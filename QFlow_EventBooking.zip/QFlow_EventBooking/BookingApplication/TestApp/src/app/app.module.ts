import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module'; 
import { FormsModule } from '@angular/forms';  
import { ReactiveFormsModule } from "@angular/forms";  
import { AppComponent } from "./app.component";
import { NgxPaginationModule} from 'ngx-pagination';  
import { Ng2SearchPipeModule } from 'ng2-search-filter';  
import { CoreModule } from './core/core-module';
import { SharedModule } from './shared/shared.module';

@NgModule({
  declarations: [AppComponent, AppRoutingModule.components],
  imports: [HttpClientModule, BrowserModule,FormsModule,  
    AppRoutingModule, HttpClientModule, ReactiveFormsModule, Ng2SearchPipeModule, NgxPaginationModule, CoreModule, SharedModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}

