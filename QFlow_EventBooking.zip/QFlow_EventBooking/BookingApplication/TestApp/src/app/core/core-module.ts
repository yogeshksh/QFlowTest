import { NgModule, Optional, SkipSelf } from '@angular/core';
import { HttpClientModule, HttpClientXsrfModule } from '@angular/common/http';
import { DataFilterService } from './data-filter.service';
import { Sorter } from './sorter';
import { EnsureModuleLoadedOnceGuard } from '../shared/ensureModuleLoadedOnceGuard';
import { CustomerDataService } from '../customers/services/customers-data.service';
import { EventsDataService } from '../events/services/events-data.service';
import { OrdersDataService } from '../orders/services/orders-data.service';
import { UserAuthGuardService } from '../authguard/user-auth-guard.service';
import { LoginService } from '../login/services/login.service';

@NgModule({
  imports: [ 
    HttpClientModule, 
  ],
  providers: [
    DataFilterService, Sorter, CustomerDataService, EventsDataService, OrdersDataService, UserAuthGuardService, LoginService ] 
})
export class CoreModule extends EnsureModuleLoadedOnceGuard {
    //Ensure that CoreModule is only loaded into AppModule

  //Looks for the module in the parent injector to see if it's already been loaded (only want it loaded once)
  constructor( @Optional() @SkipSelf() parentModule: CoreModule) {
    super(parentModule);
  }  

}




