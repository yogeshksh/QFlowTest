import { Component, Input, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { CustomerModel } from './models/customer-model';

@Component({ 
  selector: 'customer', 
  templateUrl: './customer.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush 
})
export class CustomerComponent implements OnInit {

  customer: CustomerModel;

  constructor() { }
   
    ngOnInit()
    {

    }

}
