import { Component, Input, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { CustomerModel } from './models/customer-model';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerDataService } from './services/customers-data.service';

@Component({ 
  selector: 'customer', 
  templateUrl: './customer.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush 
})
export class CustomerComponent implements OnInit {

  customer: CustomerModel;
  userId: number

  constructor(private router: Router,
    private route: ActivatedRoute,
    private dataService: CustomerDataService,) { }
   
    ngOnInit()
    {
      //hard coded for this demo, retrive from login service after user logged in successfully
      this.userId = 1;
      //let id = this.route.snapshot.params['id'];
      this.LoadCustomerOrders(this.userId);  
    }
     LoadCustomerOrders(id: number) {
       this.dataService.GetCustomerDetails(id)
      .subscribe(data => {
        this.customer = data;
      });
  }  
}
