"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CustomerModel = /** @class */ (function () {
    function CustomerModel() {
    }
    return CustomerModel;
}());
exports.CustomerModel = CustomerModel;
//# sourceMappingURL=customer-model.js.map