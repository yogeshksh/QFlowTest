﻿import { OrderModel } from "../../orders/models/order-model";
export class CustomerModel {
    public id: number;
    public firstName: string;
    public lastName: string;
    public email: string;
    public address: string;
    public city: string;
    public postCode: string;
    public gender: string
    public orders: OrderModel[]
}