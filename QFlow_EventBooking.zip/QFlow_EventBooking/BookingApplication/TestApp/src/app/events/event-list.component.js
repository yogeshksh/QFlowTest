"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var customer_model_1 = require("../customers/models/customer-model");
var events_data_service_1 = require("./services/events-data.service");
var event_model_1 = require("./models/event-model");
var orders_data_service_1 = require("../orders/services/orders-data.service");
var order_model_1 = require("../orders/models/order-model");
var EventListComponent = /** @class */ (function () {
    function EventListComponent(router, route, dataService, orderDataService) {
        this.router = router;
        this.route = route;
        this.dataService = dataService;
        this.orderDataService = orderDataService;
    }
    EventListComponent.prototype.ngOnInit = function () {
        var id = this.route.snapshot.params['id'];
        this.LoadAvailableEvents();
    };
    EventListComponent.prototype.LoadAvailableEvents = function () {
        var _this = this;
        this.dataService.GetAllAvailableEvents()
            .subscribe(function (data) {
            _this.events = data;
        });
    };
    EventListComponent.prototype.BookEvent = function (eventId) {
        var _this = this;
        event.preventDefault();
        var ordermodel = new order_model_1.OrderModel();
        ordermodel.customerId = this.custId;
        var eventData = new event_model_1.EventModel();
        eventData.id = eventId;
        ordermodel.eventData = eventData;
        this.orderDataService.AddBooking(ordermodel)
            .subscribe(function (status) {
            if (status) {
                _this.router.navigate(['/Dashboard']);
            }
            else {
                _this.errorMessage = 'Unable to book event';
            }
        }, function (err) { return console.log(err); });
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", customer_model_1.CustomerModel)
    ], EventListComponent.prototype, "customer", void 0);
    EventListComponent = __decorate([
        core_1.Component({
            selector: 'eventlist',
            templateUrl: './event-list.component.html'
        }),
        __metadata("design:paramtypes", [router_1.Router,
            router_1.ActivatedRoute,
            events_data_service_1.EventsDataService,
            orders_data_service_1.OrdersDataService])
    ], EventListComponent);
    return EventListComponent;
}());
exports.EventListComponent = EventListComponent;
//# sourceMappingURL=event-list.component.js.map