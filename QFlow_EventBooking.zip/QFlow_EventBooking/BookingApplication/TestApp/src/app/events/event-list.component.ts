import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CustomerModel } from '../customers/models/customer-model';
import { EventsDataService } from './services/events-data.service';
import { EventModel } from './models/event-model';
import { OrdersDataService } from '../orders/services/orders-data.service';
import { OrderModel } from '../orders/models/order-model';

@Component({
  selector: 'eventlist',
  templateUrl: './event-list.component.html'
})
export class EventListComponent implements OnInit {
    @Input() customer: CustomerModel;  
    custId: number;
    errorMessage: string;

    private events: EventModel[]; 
    constructor(private router: Router, 
              private route: ActivatedRoute, 
              private dataService: EventsDataService,
              private orderDataService: OrdersDataService
    ) { }

    ngOnInit()
    {
        let id = this.route.snapshot.params['id'];
        this.LoadAvailableEvents();  
    }
    LoadAvailableEvents()
    {
        this.dataService.GetAllAvailableEvents()
            .subscribe(data => {
                this.events = data;
            });
    }  

    

  BookEvent(eventId: any) {
      event.preventDefault();
      let ordermodel = new OrderModel();
      ordermodel.customerId = this.custId;
      let eventData = new EventModel();
      eventData.id = eventId;
      ordermodel.eventData = eventData;

      this.orderDataService.AddBooking(ordermodel)
        .subscribe((status: boolean) => {
          if (status) {
            this.router.navigate(['/Dashboard']);
          }
          else {
            this.errorMessage = 'Unable to book event';
          }
        },
        (err) => console.log(err));
  }
}
