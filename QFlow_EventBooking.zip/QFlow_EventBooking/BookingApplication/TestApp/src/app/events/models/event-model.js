"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var EventModel = /** @class */ (function () {
    function EventModel() {
    }
    return EventModel;
}());
exports.EventModel = EventModel;
//# sourceMappingURL=event-model.js.map