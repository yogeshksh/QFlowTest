﻿export class EventModel {
    public id: number;
    public name: string;
    public availabilityStatus: string;
}
