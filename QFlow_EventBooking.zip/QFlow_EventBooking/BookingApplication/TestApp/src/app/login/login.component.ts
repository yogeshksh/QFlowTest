import { Component , OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginModel } from './models/login-model';
import { LoginService } from './services/login.service';

@Component({
    templateUrl: './login.html',
    styleUrls: ['../content/vendor/bootstrap/css/bootstrap.min.css',
        '../content/vendor/metisMenu/metisMenu.min.css',
        '../content/dist/css/sb-admin-2.css',
        '../content/vendor/font-awesome/css/font-awesome.min.css'
    ]
})

export class LoginComponent implements OnInit
{
    ngOnInit(): void {
        localStorage.clear();
    }
    private _loginservice;

    constructor(private _Route: Router, loginservice: LoginService) 
    {
        this._loginservice = loginservice;
    }

    LoginModel: LoginModel = new LoginModel();

    onSubmit() 
    {
        this._loginservice.validateLoginUser(this.LoginModel).subscribe(
            response => 
            {     
                if (response.Token == null && response.Usertype == "0") 
                {
                    this._Route.navigate(['Login']);
                }
              
                if (response.Usertype != "0") 
                {
                    this._Route.navigate(['dashboard']);
                }
            });
    }
}
