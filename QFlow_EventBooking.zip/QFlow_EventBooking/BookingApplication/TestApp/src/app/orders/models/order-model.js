"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var OrderModel = /** @class */ (function () {
    function OrderModel() {
    }
    return OrderModel;
}());
exports.OrderModel = OrderModel;
//# sourceMappingURL=order-model.js.map