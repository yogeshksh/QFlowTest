﻿import { EventModel } from "../../events/models/event-model";

export class OrderModel {
    public id: number;
    public numberofTickets: number;
    public status: string;
    public eventData: EventModel;
    public customerId: number
}