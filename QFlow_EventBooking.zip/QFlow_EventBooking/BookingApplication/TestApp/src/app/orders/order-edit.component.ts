import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { OrderModel } from './models/order-model';
import { OrdersDataService } from './services/orders-data.service';

@Component({
  selector: 'order-edit',
  templateUrl: './order-edit.component.html'
})
export class OrderEditComponent implements OnInit {

  order: OrderModel;
  errorMessage: string;
  
  constructor(private router: Router, 
              private route: ActivatedRoute, 
              private dataService: OrdersDataService) { }

  ngOnInit() {
    let orderid = this.route.snapshot.params['orderid'];
      if (orderid !== '0')
      {
          this.getOrder(orderid);
       }
  }

  getOrder(orderId: number) {
      this.dataService.GetOrderDetails(orderId)
        .subscribe((order: OrderModel) => {
          this.order = order;
        },
        (err: any) => console.log(err));
  }

 
  submit() {

      if (this.order.id) {

        this.dataService.UpdateBookingOrder(this.order)
          .subscribe((order: OrderModel) => {
              if (order) {
              this.router.navigate(['/dashboard']);
            } else {
              this.errorMessage = 'Unable to update booking';
            }
          },
          (err: any) => console.log(err));

      } 
  }
  
  cancel(event: Event) {
    event.preventDefault();
    this.router.navigate(['/']);
  }

  delete(event: Event) {
    event.preventDefault();
      this.dataService.CancelOrder(this.order.id)
        .subscribe((status: boolean) => {
          if (status) {
            this.router.navigate(['/dashboard']);
          }
          else {
            this.errorMessage = 'Unable to cancel(delete) booking';
          }
        },
        (err) => console.log(err));
  }

}