"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var orders_data_service_1 = require("./services/orders-data.service");
var OrderListComponent = /** @class */ (function () {
    function OrderListComponent(router, route, dataService) {
        this.router = router;
        this.route = route;
        this.dataService = dataService;
        this.orders = [];
    }
    OrderListComponent.prototype.ngOnInit = function () {
    };
    OrderListComponent.prototype.UpdateOrder = function (orderId, customerId) {
        this.router.navigate(['Update', orderId, customerId]);
    };
    OrderListComponent.prototype.CancelOrder = function (orderId, customerId) {
        var _this = this;
        if (confirm("Are You Sure To cancel this booking?")) {
            this.dataService.CancelOrder(orderId).subscribe(function (response) {
                if (response.StatusCode == "200") {
                    alert('Cancelled booking Successfully');
                    location.reload();
                }
                else {
                    alert('Something Went Wrong');
                    _this.router.navigate(['Dashboard']);
                }
            });
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Array)
    ], OrderListComponent.prototype, "orders", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], OrderListComponent.prototype, "customerId", void 0);
    OrderListComponent = __decorate([
        core_1.Component({
            selector: 'orderlist',
            templateUrl: './order-list.component.html'
        }),
        __metadata("design:paramtypes", [router_1.Router,
            router_1.ActivatedRoute,
            orders_data_service_1.OrdersDataService])
    ], OrderListComponent);
    return OrderListComponent;
}());
exports.OrderListComponent = OrderListComponent;
//# sourceMappingURL=order-list.component.js.map