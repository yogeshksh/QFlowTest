import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { OrderModel } from './models/order-model';
import { OrdersDataService } from './services/orders-data.service';

@Component({
  selector: 'orderlist',
  templateUrl: './order-list.component.html'
})
export class OrderListComponent implements OnInit {

    @Input() orders: OrderModel[] = [];
    @Input() customerId: number;
 
  errorMessage: string;
  deleteMessageEnabled: boolean;
  
  constructor(private router: Router, 
              private route: ActivatedRoute, 
              private dataService: OrdersDataService) { }

  ngOnInit() {
    
  } 

    UpdateOrder(orderId: number, customerId: number)
    {
        this.router.navigate(['Update', orderId, customerId]);  
    }

    CancelOrder(orderId: number, customerId: number) {
        if (confirm("Are You Sure To cancel this booking?")) {

            this.dataService.CancelOrder(orderId).subscribe(
                response => {
                    if (response.StatusCode == "200") {
                        alert('Cancelled booking Successfully');
                        location.reload();
                    }
                    else {
                        alert('Something Went Wrong');
                        this.router.navigate(['Dashboard']);
                    }
                }
            );
        }
    }  

}