using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Web.Http.Results;
using QFlow_EventBooking.Controllers;
using QFlow_EventBooking.Repository;
using QFlow_EventBooking.Models;
using System.Threading.Tasks;

namespace BookingUnitTestProject
{
    [TestClass]
    public class CustomersControllerUnitTest
    {
        [TestMethod]
        public void TestGetReturnsCustomer()
        {
            // Arrange
            var mockRepository = new Mock<ICustomersRepository>();
            var mockLogger = new Mock<ILoggerFactory>();
            var mockCustomer= new Customer{ FirstName = "TestFirst1", LastName = "TestLast1", Orders = null };


            mockRepository.Setup(x => x.GetCustomerAsync(5))
                .Returns(Task.FromResult(mockCustomer));
            var controller = new CustomersController( mockRepository.Object, mockLogger.Object);

            // Act
            var actionResult = controller.Get();

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(actionResult.Result);
        }


        [TestMethod]
        public void TestGetReturnsNoCustomer()
        {
          
        }

    }
}
