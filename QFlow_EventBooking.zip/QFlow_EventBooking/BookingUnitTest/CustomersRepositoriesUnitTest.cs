using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject
{

    
    [TestClass]
    public class CustomersRepositoriesUnitTest
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
