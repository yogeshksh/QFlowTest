﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace QFlow_EventBooking_UnitTest
{
    [TestClass]
    public class EventOrderControllerUnitTest
    {
        [TestMethod]
        public void TestGetEvents()
        {
            //Arrange

            //Act

            //Assert

        }

    }
}