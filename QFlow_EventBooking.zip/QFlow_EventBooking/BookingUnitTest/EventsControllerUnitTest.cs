﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace QFlow_EventBooking_UnitTest
{
    [TestClass]
    public class EventsControllerUnitTest
    {
        [TestMethod]
        public void TestGetEvents()
        {
            //Arrange

            //Act

            //Assert

        }

    }
}