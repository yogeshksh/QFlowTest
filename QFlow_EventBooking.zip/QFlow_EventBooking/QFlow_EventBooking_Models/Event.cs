namespace QFlow_EventBooking.Models {
  public class Event {
    public int Id { get; set; }
    public string Name { get; set; }
    public bool AvailabilityStatus { get; set; }
  }
}