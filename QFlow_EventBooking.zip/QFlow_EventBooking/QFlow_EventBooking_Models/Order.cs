namespace QFlow_EventBooking.Models {
  public class Order {
        public int Id { get; set; }
        public int NumberofTickets { get; set; }
        public string Status { get; set; }
        public Event EventData { get; set; }
        public int CustomerId { get; set; }
  }
}