﻿using System;

namespace QFlow_EventBooking_ViewModels
{
    public class CustomerOrderModel
    {

    }
}
