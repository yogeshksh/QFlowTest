﻿Info:

I have created a  solution that contains a standard Asp.Net Core project with an Angular cli project.
 Using Visual Studio F5 will build both the server side and client side code and launch the website.

Once running the client side code (found in TestApp/src) 



